(function $csb$eval(require, module, exports, process, global, __dirname, __filename, $csbImport) {var _csbRefreshUtils = require("/node_modules/csbbust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = App;

var _taggedTemplateLiteral2 = _interopRequireDefault(require("@babel/runtime/helpers/taggedTemplateLiteral"));

var _reactSpline = _interopRequireDefault(require("@splinetool/react-spline"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _logo = _interopRequireDefault(require("./images/logo.svg"));

var _iconTwitter = _interopRequireDefault(require("./images/icon-twitter.svg"));

var _iconYoutube = _interopRequireDefault(require("./images/icon-youtube.svg"));

var _iconLaptop = _interopRequireDefault(require("./images/icon-laptop.svg"));

var _jsxRuntime = require("react/jsx-runtime");

var _jsxFileName = "/src/App.js",
    _templateObject,
    _templateObject2,
    _templateObject3,
    _templateObject4;

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(Wrapper, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_reactSpline.default, {
      className: "spline",
      scene: "https://prod.spline.design/k99HVzraHEeIFQii/scene.splinecode"
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(Social, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {}), /*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
        src: _iconTwitter.default,
        alt: "Twitter"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
        src: _iconYoutube.default,
        alt: "YouTube"
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(Content, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(Menu, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
            src: _logo.default,
            alt: "title"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
            href: "/",
            children: "Home"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
            href: "/",
            children: "Download"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
            href: "/",
            children: "App"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
            href: "/",
            children: "Login"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            children: "Get Started"
          })
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
        children: "Collaborate with people"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        children: "Bring your team together and build your community by using our cross-platform app that lets you collaborate via chat, voice and by sharing and storing unlimited media files. A world of topics is waiting for you. Join the private beta."
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
          src: _iconLaptop.default,
          alt: ""
        }), " Download for Mac"]
      })]
    })]
  });
}

_c = App;

const Wrapper = _styledComponents.default.div(_templateObject || (_templateObject = (0, _taggedTemplateLiteral2.default)(["\n  font-family: \"Spline Sans\", sans-serif;\n  color: white;\n  font-size: 16px;\n  margin: 0 auto;\n  position: relative;\n  height: 100%;\n  overflow-x: hidden;\n\n  .spline {\n    position: absolute;\n    margin: 0;\n    top: 0;\n    right: 0;\n    width: 1200px;\n    height: 1000px;\n\n    @media (max-width: 1024px) {\n      transform: scale(0.8) translateX(200px);\n      transform-origin: top;\n    }\n    @media (max-width: 800px) {\n      transform: scale(0.7) translateX(600px);\n    }\n    @media (max-width: 600px) {\n      transform: scale(0.5) translateX(-100px);\n      right: auto;\n      left: 50%;\n      margin-left: -600px;\n    }\n    @media (max-width: 375px) {\n      transform: scale(0.45) translateX(-50px);\n    }\n  }\n"])));

_c2 = Wrapper;

const Content = _styledComponents.default.div(_templateObject2 || (_templateObject2 = (0, _taggedTemplateLiteral2.default)(["\n  position: absolute;\n  top: 30px;\n  width: 100%;\n  padding-bottom: 100px;\n  pointer-events: none;\n\n  display: flex;\n  flex-direction: column;\n  gap: 80px;\n\n  @media (max-width: 1024px) {\n    gap: 40px;\n  }\n\n  h1 {\n    font-weight: bold;\n    font-family: \"Spline Sans Mono\", monospace;\n    font-size: 70px;\n    margin: 0;\n    max-width: 500px;\n    pointer-events: auto;\n    text-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);\n\n    @media (max-width: 1024px) {\n      font-size: 60px;\n      max-width: 400px;\n    }\n    @media (max-width: 800px) {\n      font-size: 40px;\n      max-width: 300px;\n    }\n    @media (max-width: 600px) {\n      padding-top: 250px;\n    }\n  }\n\n  p {\n    font-weight: normal;\n    line-height: 150%;\n    max-width: 380px;\n    pointer-events: auto;\n    text-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);\n  }\n\n  button {\n    background: rgba(0, 0, 0, 0.2);\n    border: 0px;\n    font-size: 16px;\n    padding: 12px 30px;\n    border-radius: 14px;\n    color: white;\n    border: 1px solid rgba(255, 255, 255, 0.1);\n    max-width: 280px;\n    backdrop-filter: blur(20px);\n    font-weight: 600;\n    box-shadow: 0 20px 20px rgba(0, 0, 0, 0.2);\n    transition: 1s;\n    cursor: pointer;\n    pointer-events: auto;\n\n    display: flex;\n    gap: 12px;\n    justify-content: center;\n    align-items: center;\n\n    :hover {\n      border: 1px solid rgba(255, 255, 255, 0.8);\n      transform: translateY(-3px);\n    }\n  }\n\n  h1,\n  p,\n  button {\n    margin: 0 30px 0 100px;\n\n    @media (max-width: 1024px) {\n      margin: 0 30px;\n    }\n  }\n"])));

_c3 = Content;

const Menu = _styledComponents.default.ul(_templateObject3 || (_templateObject3 = (0, _taggedTemplateLiteral2.default)(["\n  display: flex;\n  gap: 30px;\n  align-items: center;\n  margin: 0 30px 0 100px;\n  padding: 0;\n  pointer-events: auto;\n\n  @media (max-width: 1024px) {\n    margin: 0 30px;\n  }\n\n  li {\n    list-style: none;\n    margin: 0;\n\n    a {\n      text-decoration: none;\n      color: white;\n      padding: 8px 20px;\n      border-radius: 14px;\n      border: 1px solid rgba(255, 255, 255, 0);\n      transition: 1s;\n\n      :hover {\n        border: 1px solid rgba(255, 255, 255, 0.2);\n      }\n    }\n  }\n\n  button {\n    margin: 0;\n    width: auto;\n    background: rgba(31, 66, 250, 0.2);\n    border: 1px solid rgba(255, 255, 255, 0.4);\n  }\n\n  @media (max-width: 800px) {\n    justify-content: space-between;\n    li:nth-child(2),\n    li:nth-child(3),\n    li:nth-child(4),\n    li:nth-child(5) {\n      display: none;\n    }\n  }\n"])));

_c4 = Menu;

const Social = _styledComponents.default.div(_templateObject4 || (_templateObject4 = (0, _taggedTemplateLiteral2.default)(["\n  position: absolute;\n  top: 150px;\n  left: 30px;\n  display: flex;\n  flex-direction: column;\n  gap: 30px;\n  align-items: center;\n\n  @media (max-width: 1024px) {\n    display: none;\n  }\n\n  div {\n    width: 1px;\n    height: 500px;\n    background: linear-gradient(\n      180deg,\n      #08b6f9 0%,\n      #6c56ef 33.57%,\n      #1306dd 65.86%,\n      #aa0eb2 100%\n    );\n  }\n"])));

_c5 = Social;

var _c, _c2, _c3, _c4, _c5;

$RefreshReg$(_c, "App");
$RefreshReg$(_c2, "Wrapper");
$RefreshReg$(_c3, "Content");
$RefreshReg$(_c4, "Menu");
$RefreshReg$(_c5, "Social");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zcmMvQXBwLmpzIl0sIm5hbWVzIjpbIkFwcCIsIkljb25Ud2l0dGVyIiwiSWNvbllvdVR1YmUiLCJMb2dvIiwiSWNvbkxhcHRvcCIsIldyYXBwZXIiLCJzdHlsZWQiLCJkaXYiLCJDb250ZW50IiwiTWVudSIsInVsIiwiU29jaWFsIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBOztBQUNBOztBQUVBOztBQUNBOztBQUNBOztBQUNBOzs7Ozs7Ozs7O0FBRWUsU0FBU0EsR0FBVCxHQUFlO0FBQzVCLHNCQUNFLHNCQUFDLE9BQUQ7QUFBQSw0QkFDRSxxQkFBQyxvQkFBRDtBQUNFLE1BQUEsU0FBUyxFQUFDLFFBRFo7QUFFRSxNQUFBLEtBQUssRUFBQztBQUZSLE1BREYsZUFLRSxzQkFBQyxNQUFEO0FBQUEsOEJBQ0UsK0JBREYsZUFFRTtBQUFLLFFBQUEsR0FBRyxFQUFFQyxvQkFBVjtBQUF1QixRQUFBLEdBQUcsRUFBQztBQUEzQixRQUZGLGVBR0U7QUFBSyxRQUFBLEdBQUcsRUFBRUMsb0JBQVY7QUFBdUIsUUFBQSxHQUFHLEVBQUM7QUFBM0IsUUFIRjtBQUFBLE1BTEYsZUFVRSxzQkFBQyxPQUFEO0FBQUEsOEJBQ0Usc0JBQUMsSUFBRDtBQUFBLGdDQUNFO0FBQUEsaUNBQ0U7QUFBSyxZQUFBLEdBQUcsRUFBRUMsYUFBVjtBQUFnQixZQUFBLEdBQUcsRUFBQztBQUFwQjtBQURGLFVBREYsZUFJRTtBQUFBLGlDQUNFO0FBQUcsWUFBQSxJQUFJLEVBQUMsR0FBUjtBQUFBO0FBQUE7QUFERixVQUpGLGVBT0U7QUFBQSxpQ0FDRTtBQUFHLFlBQUEsSUFBSSxFQUFDLEdBQVI7QUFBQTtBQUFBO0FBREYsVUFQRixlQVVFO0FBQUEsaUNBQ0U7QUFBRyxZQUFBLElBQUksRUFBQyxHQUFSO0FBQUE7QUFBQTtBQURGLFVBVkYsZUFhRTtBQUFBLGlDQUNFO0FBQUcsWUFBQSxJQUFJLEVBQUMsR0FBUjtBQUFBO0FBQUE7QUFERixVQWJGLGVBZ0JFO0FBQUEsaUNBQ0U7QUFBQTtBQUFBO0FBREYsVUFoQkY7QUFBQSxRQURGLGVBcUJFO0FBQUE7QUFBQSxRQXJCRixlQXNCRTtBQUFBO0FBQUEsUUF0QkYsZUE0QkU7QUFBQSxnQ0FDRTtBQUFLLFVBQUEsR0FBRyxFQUFFQyxtQkFBVjtBQUFzQixVQUFBLEdBQUcsRUFBQztBQUExQixVQURGO0FBQUEsUUE1QkY7QUFBQSxNQVZGO0FBQUEsSUFERjtBQTZDRDs7S0E5Q3VCSixHOztBQWdEeEIsTUFBTUssT0FBTyxHQUFHQywwQkFBT0MsR0FBVixnMEJBQWI7O01BQU1GLE87O0FBb0NOLE1BQU1HLE9BQU8sR0FBR0YsMEJBQU9DLEdBQVYsNHBEQUFiOztNQUFNQyxPOztBQW1GTixNQUFNQyxJQUFJLEdBQUdILDBCQUFPSSxFQUFWLHU2QkFBVjs7TUFBTUQsSTs7QUFnRE4sTUFBTUUsTUFBTSxHQUFHTCwwQkFBT0MsR0FBViw2ZEFBWjs7TUFBTUksTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBTcGxpbmUgZnJvbSBcIkBzcGxpbmV0b29sL3JlYWN0LXNwbGluZVwiO1xuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcblxuaW1wb3J0IExvZ28gZnJvbSBcIi4vaW1hZ2VzL2xvZ28uc3ZnXCI7XG5pbXBvcnQgSWNvblR3aXR0ZXIgZnJvbSBcIi4vaW1hZ2VzL2ljb24tdHdpdHRlci5zdmdcIjtcbmltcG9ydCBJY29uWW91VHViZSBmcm9tIFwiLi9pbWFnZXMvaWNvbi15b3V0dWJlLnN2Z1wiO1xuaW1wb3J0IEljb25MYXB0b3AgZnJvbSBcIi4vaW1hZ2VzL2ljb24tbGFwdG9wLnN2Z1wiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiAoXG4gICAgPFdyYXBwZXI+XG4gICAgICA8U3BsaW5lXG4gICAgICAgIGNsYXNzTmFtZT1cInNwbGluZVwiXG4gICAgICAgIHNjZW5lPVwiaHR0cHM6Ly9wcm9kLnNwbGluZS5kZXNpZ24vazk5SFZ6cmFIRWVJRlFpaS9zY2VuZS5zcGxpbmVjb2RlXCJcbiAgICAgIC8+XG4gICAgICA8U29jaWFsPlxuICAgICAgICA8ZGl2IC8+XG4gICAgICAgIDxpbWcgc3JjPXtJY29uVHdpdHRlcn0gYWx0PVwiVHdpdHRlclwiIC8+XG4gICAgICAgIDxpbWcgc3JjPXtJY29uWW91VHViZX0gYWx0PVwiWW91VHViZVwiIC8+XG4gICAgICA8L1NvY2lhbD5cbiAgICAgIDxDb250ZW50PlxuICAgICAgICA8TWVudT5cbiAgICAgICAgICA8bGk+XG4gICAgICAgICAgICA8aW1nIHNyYz17TG9nb30gYWx0PVwidGl0bGVcIiAvPlxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgPGxpPlxuICAgICAgICAgICAgPGEgaHJlZj1cIi9cIj5Ib21lPC9hPlxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgPGxpPlxuICAgICAgICAgICAgPGEgaHJlZj1cIi9cIj5Eb3dubG9hZDwvYT5cbiAgICAgICAgICA8L2xpPlxuICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIvXCI+QXBwPC9hPlxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgPGxpPlxuICAgICAgICAgICAgPGEgaHJlZj1cIi9cIj5Mb2dpbjwvYT5cbiAgICAgICAgICA8L2xpPlxuICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgIDxidXR0b24+R2V0IFN0YXJ0ZWQ8L2J1dHRvbj5cbiAgICAgICAgICA8L2xpPlxuICAgICAgICA8L01lbnU+XG4gICAgICAgIDxoMT5Db2xsYWJvcmF0ZSB3aXRoIHBlb3BsZTwvaDE+XG4gICAgICAgIDxwPlxuICAgICAgICAgIEJyaW5nIHlvdXIgdGVhbSB0b2dldGhlciBhbmQgYnVpbGQgeW91ciBjb21tdW5pdHkgYnkgdXNpbmcgb3VyXG4gICAgICAgICAgY3Jvc3MtcGxhdGZvcm0gYXBwIHRoYXQgbGV0cyB5b3UgY29sbGFib3JhdGUgdmlhIGNoYXQsIHZvaWNlIGFuZCBieVxuICAgICAgICAgIHNoYXJpbmcgYW5kIHN0b3JpbmcgdW5saW1pdGVkIG1lZGlhIGZpbGVzLiBBIHdvcmxkIG9mIHRvcGljcyBpc1xuICAgICAgICAgIHdhaXRpbmcgZm9yIHlvdS4gSm9pbiB0aGUgcHJpdmF0ZSBiZXRhLlxuICAgICAgICA8L3A+XG4gICAgICAgIDxidXR0b24+XG4gICAgICAgICAgPGltZyBzcmM9e0ljb25MYXB0b3B9IGFsdD1cIlwiIC8+IERvd25sb2FkIGZvciBNYWNcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L0NvbnRlbnQ+XG4gICAgPC9XcmFwcGVyPlxuICApO1xufVxuXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgZm9udC1mYW1pbHk6IFwiU3BsaW5lIFNhbnNcIiwgc2Fucy1zZXJpZjtcbiAgY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbjogMCBhdXRvO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGhlaWdodDogMTAwJTtcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xuXG4gIC5zcGxpbmUge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBtYXJnaW46IDA7XG4gICAgdG9wOiAwO1xuICAgIHJpZ2h0OiAwO1xuICAgIHdpZHRoOiAxMjAwcHg7XG4gICAgaGVpZ2h0OiAxMDAwcHg7XG5cbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTAyNHB4KSB7XG4gICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuOCkgdHJhbnNsYXRlWCgyMDBweCk7XG4gICAgICB0cmFuc2Zvcm0tb3JpZ2luOiB0b3A7XG4gICAgfVxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA4MDBweCkge1xuICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwLjcpIHRyYW5zbGF0ZVgoNjAwcHgpO1xuICAgIH1cbiAgICBAbWVkaWEgKG1heC13aWR0aDogNjAwcHgpIHtcbiAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC41KSB0cmFuc2xhdGVYKC0xMDBweCk7XG4gICAgICByaWdodDogYXV0bztcbiAgICAgIGxlZnQ6IDUwJTtcbiAgICAgIG1hcmdpbi1sZWZ0OiAtNjAwcHg7XG4gICAgfVxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiAzNzVweCkge1xuICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwLjQ1KSB0cmFuc2xhdGVYKC01MHB4KTtcbiAgICB9XG4gIH1cbmA7XG5cbmNvbnN0IENvbnRlbnQgPSBzdHlsZWQuZGl2YFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMzBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxMDBweDtcbiAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG5cbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgZ2FwOiA4MHB4O1xuXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMDI0cHgpIHtcbiAgICBnYXA6IDQwcHg7XG4gIH1cblxuICBoMSB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1mYW1pbHk6IFwiU3BsaW5lIFNhbnMgTW9ub1wiLCBtb25vc3BhY2U7XG4gICAgZm9udC1zaXplOiA3MHB4O1xuICAgIG1hcmdpbjogMDtcbiAgICBtYXgtd2lkdGg6IDUwMHB4O1xuICAgIHBvaW50ZXItZXZlbnRzOiBhdXRvO1xuICAgIHRleHQtc2hhZG93OiAwIDEwcHggMzBweCByZ2JhKDAsIDAsIDAsIDAuNSk7XG5cbiAgICBAbWVkaWEgKG1heC13aWR0aDogMTAyNHB4KSB7XG4gICAgICBmb250LXNpemU6IDYwcHg7XG4gICAgICBtYXgtd2lkdGg6IDQwMHB4O1xuICAgIH1cbiAgICBAbWVkaWEgKG1heC13aWR0aDogODAwcHgpIHtcbiAgICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICAgIG1heC13aWR0aDogMzAwcHg7XG4gICAgfVxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA2MDBweCkge1xuICAgICAgcGFkZGluZy10b3A6IDI1MHB4O1xuICAgIH1cbiAgfVxuXG4gIHAge1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDE1MCU7XG4gICAgbWF4LXdpZHRoOiAzODBweDtcbiAgICBwb2ludGVyLWV2ZW50czogYXV0bztcbiAgICB0ZXh0LXNoYWRvdzogMCAxMHB4IDMwcHggcmdiYSgwLCAwLCAwLCAwLjUpO1xuICB9XG5cbiAgYnV0dG9uIHtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMik7XG4gICAgYm9yZGVyOiAwcHg7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIHBhZGRpbmc6IDEycHggMzBweDtcbiAgICBib3JkZXItcmFkaXVzOiAxNHB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSk7XG4gICAgbWF4LXdpZHRoOiAyODBweDtcbiAgICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoMjBweCk7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBib3gtc2hhZG93OiAwIDIwcHggMjBweCByZ2JhKDAsIDAsIDAsIDAuMik7XG4gICAgdHJhbnNpdGlvbjogMXM7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHBvaW50ZXItZXZlbnRzOiBhdXRvO1xuXG4gICAgZGlzcGxheTogZmxleDtcbiAgICBnYXA6IDEycHg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgIDpob3ZlciB7XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOCk7XG4gICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTNweCk7XG4gICAgfVxuICB9XG5cbiAgaDEsXG4gIHAsXG4gIGJ1dHRvbiB7XG4gICAgbWFyZ2luOiAwIDMwcHggMCAxMDBweDtcblxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiAxMDI0cHgpIHtcbiAgICAgIG1hcmdpbjogMCAzMHB4O1xuICAgIH1cbiAgfVxuYDtcblxuY29uc3QgTWVudSA9IHN0eWxlZC51bGBcbiAgZGlzcGxheTogZmxleDtcbiAgZ2FwOiAzMHB4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW46IDAgMzBweCAwIDEwMHB4O1xuICBwYWRkaW5nOiAwO1xuICBwb2ludGVyLWV2ZW50czogYXV0bztcblxuICBAbWVkaWEgKG1heC13aWR0aDogMTAyNHB4KSB7XG4gICAgbWFyZ2luOiAwIDMwcHg7XG4gIH1cblxuICBsaSB7XG4gICAgbGlzdC1zdHlsZTogbm9uZTtcbiAgICBtYXJnaW46IDA7XG5cbiAgICBhIHtcbiAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgIHBhZGRpbmc6IDhweCAyMHB4O1xuICAgICAgYm9yZGVyLXJhZGl1czogMTRweDtcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMjU1LCAyNTUsIDI1NSwgMCk7XG4gICAgICB0cmFuc2l0aW9uOiAxcztcblxuICAgICAgOmhvdmVyIHtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjIpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGJ1dHRvbiB7XG4gICAgbWFyZ2luOiAwO1xuICAgIHdpZHRoOiBhdXRvO1xuICAgIGJhY2tncm91bmQ6IHJnYmEoMzEsIDY2LCAyNTAsIDAuMik7XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjQpO1xuICB9XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDgwMHB4KSB7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIGxpOm50aC1jaGlsZCgyKSxcbiAgICBsaTpudGgtY2hpbGQoMyksXG4gICAgbGk6bnRoLWNoaWxkKDQpLFxuICAgIGxpOm50aC1jaGlsZCg1KSB7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cbiAgfVxuYDtcblxuY29uc3QgU29jaWFsID0gc3R5bGVkLmRpdmBcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDE1MHB4O1xuICBsZWZ0OiAzMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBnYXA6IDMwcHg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDEwMjRweCkge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICBkaXYge1xuICAgIHdpZHRoOiAxcHg7XG4gICAgaGVpZ2h0OiA1MDBweDtcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoXG4gICAgICAxODBkZWcsXG4gICAgICAjMDhiNmY5IDAlLFxuICAgICAgIzZjNTZlZiAzMy41NyUsXG4gICAgICAjMTMwNmRkIDY1Ljg2JSxcbiAgICAgICNhYTBlYjIgMTAwJVxuICAgICk7XG4gIH1cbmA7XG4iXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}
//# sourceURL=https://t36bh6.csb.app/src/App.js
})