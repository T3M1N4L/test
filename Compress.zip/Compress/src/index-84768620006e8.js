(function $csb$eval(require, module, exports, process, global, __dirname, __filename, $csbImport) {var _csbRefreshUtils = require("/node_modules/csbbust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _react = require("react");

var _client = require("react-dom/client");

require("./styles.css");

var _App = _interopRequireDefault(require("./App"));

var _jsxRuntime = require("react/jsx-runtime");

var _jsxFileName = "/src/index.js";
const rootElement = document.getElementById('root');
const root = (0, _client.createRoot)(rootElement);
root.render( /*#__PURE__*/(0, _jsxRuntime.jsx)(_react.StrictMode, {
  children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {})
}));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zcmMvaW5kZXguanMiXSwibmFtZXMiOlsicm9vdEVsZW1lbnQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicm9vdCIsInJlbmRlciJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBOztBQUNBOztBQUNBOztBQUNBOzs7OztBQUVBLE1BQU1BLFdBQVcsR0FBR0MsUUFBUSxDQUFDQyxjQUFULENBQXdCLE1BQXhCLENBQXBCO0FBQ0EsTUFBTUMsSUFBSSxHQUFHLHdCQUFXSCxXQUFYLENBQWI7QUFDQUcsSUFBSSxDQUFDQyxNQUFMLGVBQ0UscUJBQUMsaUJBQUQ7QUFBQSx5QkFDRSxxQkFBQyxZQUFEO0FBREYsRUFERiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgJy4vc3R5bGVzLmNzcyc7XG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwJztcblxuY29uc3Qgcm9vdEVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpO1xuY29uc3Qgcm9vdCA9IGNyZWF0ZVJvb3Qocm9vdEVsZW1lbnQpO1xucm9vdC5yZW5kZXIoXG4gIDxTdHJpY3RNb2RlPlxuICAgIDxBcHAgLz5cbiAgPC9TdHJpY3RNb2RlPlxuKTtcbiJdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}
//# sourceURL=https://t36bh6.csb.app/src/index.js
})